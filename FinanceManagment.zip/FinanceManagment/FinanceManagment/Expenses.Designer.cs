﻿namespace FinanceManagment
{
    partial class Expenses
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Expenses));
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            panel1 = new Panel();
            panel3 = new Panel();
            pictureBox7 = new PictureBox();
            pictureBox8 = new PictureBox();
            pictureBox10 = new PictureBox();
            pictureBox11 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox1 = new PictureBox();
            panel2 = new Panel();
            pictureBox6 = new PictureBox();
            ZarzadzanieFinansami = new Label();
            ExpNameBox = new TextBox();
            Wydatek = new Label();
            Wartość = new Label();
            Kategoria = new Label();
            Data = new Label();
            Opis = new Label();
            ExpDescBox = new TextBox();
            ExpCatBox = new TextBox();
            ExpValueBox = new TextBox();
            Dodaj = new Button();
            Edytuj = new Button();
            Usuń = new Button();
            ExpList = new Guna.UI2.WinForms.Guna2DataGridView();
            ListaWydatkow = new Label();
            DateTab = new Guna.UI2.WinForms.Guna2DateTimePicker();
            panel1.SuspendLayout();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ExpList).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(49, 48, 77);
            panel1.Controls.Add(panel3);
            panel1.Controls.Add(pictureBox2);
            panel1.Controls.Add(pictureBox3);
            panel1.Controls.Add(pictureBox4);
            panel1.Controls.Add(pictureBox5);
            panel1.Controls.Add(pictureBox1);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(74, 728);
            panel1.TabIndex = 0;
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(49, 48, 77);
            panel3.Controls.Add(pictureBox7);
            panel3.Controls.Add(pictureBox8);
            panel3.Controls.Add(pictureBox10);
            panel3.Controls.Add(pictureBox11);
            panel3.Dock = DockStyle.Left;
            panel3.Location = new Point(0, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(74, 728);
            panel3.TabIndex = 6;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(0, 618);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(74, 79);
            pictureBox7.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox7.TabIndex = 2;
            pictureBox7.TabStop = false;
            pictureBox7.Click += pictureBox7_Click;
            // 
            // pictureBox8
            // 
            pictureBox8.Image = (Image)resources.GetObject("pictureBox8.Image");
            pictureBox8.Location = new Point(0, 376);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(71, 62);
            pictureBox8.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox8.TabIndex = 3;
            pictureBox8.TabStop = false;
            pictureBox8.Click += pictureBox8_Click;
            // 
            // pictureBox10
            // 
            pictureBox10.Image = (Image)resources.GetObject("pictureBox10.Image");
            pictureBox10.Location = new Point(0, 278);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(71, 62);
            pictureBox10.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox10.TabIndex = 5;
            pictureBox10.TabStop = false;
            pictureBox10.Click += pictureBox10_Click;
            // 
            // pictureBox11
            // 
            pictureBox11.Image = (Image)resources.GetObject("pictureBox11.Image");
            pictureBox11.Location = new Point(3, 170);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(68, 62);
            pictureBox11.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox11.TabIndex = 0;
            pictureBox11.TabStop = false;
            pictureBox11.Click += pictureBox11_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(0, 618);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(74, 79);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 2;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(0, 376);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(71, 62);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 3;
            pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(3, 294);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(68, 62);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 4;
            pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(0, 210);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(71, 62);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 5;
            pictureBox5.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(3, 130);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(68, 62);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(182, 187, 196);
            panel2.Controls.Add(pictureBox6);
            panel2.Controls.Add(ZarzadzanieFinansami);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(74, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(1265, 65);
            panel2.TabIndex = 1;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(331, 3);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(68, 62);
            pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox6.TabIndex = 5;
            pictureBox6.TabStop = false;
            // 
            // ZarzadzanieFinansami
            // 
            ZarzadzanieFinansami.AutoSize = true;
            ZarzadzanieFinansami.Font = new Font("Times New Roman", 18F, FontStyle.Regular, GraphicsUnit.Point, 238);
            ZarzadzanieFinansami.ForeColor = Color.FromArgb(240, 236, 229);
            ZarzadzanieFinansami.Location = new Point(31, 18);
            ZarzadzanieFinansami.Name = "ZarzadzanieFinansami";
            ZarzadzanieFinansami.Size = new Size(280, 34);
            ZarzadzanieFinansami.TabIndex = 4;
            ZarzadzanieFinansami.Text = "Zarzadzanie finansami";
            // 
            // ExpNameBox
            // 
            ExpNameBox.BackColor = Color.FromArgb(22, 26, 48);
            ExpNameBox.ForeColor = SystemColors.Menu;
            ExpNameBox.Location = new Point(105, 162);
            ExpNameBox.Name = "ExpNameBox";
            ExpNameBox.Size = new Size(252, 30);
            ExpNameBox.TabIndex = 2;
            // 
            // Wydatek
            // 
            Wydatek.AutoSize = true;
            Wydatek.ForeColor = Color.FromArgb(240, 236, 229);
            Wydatek.Location = new Point(106, 139);
            Wydatek.Name = "Wydatek";
            Wydatek.Size = new Size(78, 22);
            Wydatek.TabIndex = 3;
            Wydatek.Text = "Wydatek";
            // 
            // Wartość
            // 
            Wartość.AutoSize = true;
            Wartość.ForeColor = Color.FromArgb(240, 236, 229);
            Wartość.Location = new Point(105, 210);
            Wartość.Name = "Wartość";
            Wartość.Size = new Size(74, 22);
            Wartość.TabIndex = 4;
            Wartość.Text = "Wartość";
            // 
            // Kategoria
            // 
            Kategoria.AutoSize = true;
            Kategoria.ForeColor = Color.FromArgb(240, 236, 229);
            Kategoria.Location = new Point(105, 294);
            Kategoria.Name = "Kategoria";
            Kategoria.Size = new Size(88, 22);
            Kategoria.TabIndex = 5;
            Kategoria.Text = "Kategoria";
            // 
            // Data
            // 
            Data.AutoSize = true;
            Data.ForeColor = Color.FromArgb(240, 236, 229);
            Data.Location = new Point(106, 376);
            Data.Name = "Data";
            Data.Size = new Size(47, 22);
            Data.TabIndex = 6;
            Data.Text = "Data";
            // 
            // Opis
            // 
            Opis.AutoSize = true;
            Opis.ForeColor = Color.FromArgb(240, 236, 229);
            Opis.Location = new Point(106, 457);
            Opis.Name = "Opis";
            Opis.Size = new Size(48, 22);
            Opis.TabIndex = 7;
            Opis.Text = "Opis";
            // 
            // ExpDescBox
            // 
            ExpDescBox.BackColor = Color.FromArgb(22, 26, 48);
            ExpDescBox.ForeColor = SystemColors.Menu;
            ExpDescBox.Location = new Point(105, 482);
            ExpDescBox.Name = "ExpDescBox";
            ExpDescBox.Size = new Size(252, 30);
            ExpDescBox.TabIndex = 8;
            ExpDescBox.TextChanged += textBox2_TextChanged;
            // 
            // ExpCatBox
            // 
            ExpCatBox.BackColor = Color.FromArgb(22, 26, 48);
            ExpCatBox.ForeColor = SystemColors.Menu;
            ExpCatBox.Location = new Point(106, 319);
            ExpCatBox.Name = "ExpCatBox";
            ExpCatBox.Size = new Size(252, 30);
            ExpCatBox.TabIndex = 10;
            // 
            // ExpValueBox
            // 
            ExpValueBox.BackColor = Color.FromArgb(22, 26, 48);
            ExpValueBox.ForeColor = SystemColors.Menu;
            ExpValueBox.Location = new Point(106, 235);
            ExpValueBox.Name = "ExpValueBox";
            ExpValueBox.Size = new Size(252, 30);
            ExpValueBox.TabIndex = 11;
            // 
            // Dodaj
            // 
            Dodaj.Location = new Point(105, 540);
            Dodaj.Name = "Dodaj";
            Dodaj.Size = new Size(122, 29);
            Dodaj.TabIndex = 12;
            Dodaj.Text = "Dodaj";
            Dodaj.UseVisualStyleBackColor = true;
            Dodaj.Click += Dodaj_Click;
            // 
            // Edytuj
            // 
            Edytuj.Location = new Point(233, 540);
            Edytuj.Name = "Edytuj";
            Edytuj.Size = new Size(124, 29);
            Edytuj.TabIndex = 13;
            Edytuj.Text = "Edytuj";
            Edytuj.UseVisualStyleBackColor = true;
            Edytuj.Click += Edytuj_Click;
            // 
            // Usuń
            // 
            Usuń.Location = new Point(166, 575);
            Usuń.Name = "Usuń";
            Usuń.Size = new Size(129, 29);
            Usuń.TabIndex = 14;
            Usuń.Text = "Usuń";
            Usuń.UseVisualStyleBackColor = true;
            Usuń.Click += Usuń_Click;
            // 
            // ExpList
            // 
            dataGridViewCellStyle1.BackColor = Color.White;
            ExpList.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(100, 88, 255);
            dataGridViewCellStyle2.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 238);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            ExpList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            ExpList.ColumnHeadersHeight = 4;
            ExpList.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.White;
            dataGridViewCellStyle3.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 238);
            dataGridViewCellStyle3.ForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dataGridViewCellStyle3.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            ExpList.DefaultCellStyle = dataGridViewCellStyle3;
            ExpList.GridColor = Color.FromArgb(231, 229, 255);
            ExpList.Location = new Point(405, 162);
            ExpList.Name = "ExpList";
            ExpList.RowHeadersVisible = false;
            ExpList.RowHeadersWidth = 51;
            ExpList.Size = new Size(862, 521);
            ExpList.TabIndex = 15;
            ExpList.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            ExpList.ThemeStyle.AlternatingRowsStyle.Font = null;
            ExpList.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            ExpList.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            ExpList.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            ExpList.ThemeStyle.BackColor = Color.White;
            ExpList.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            ExpList.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            ExpList.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            ExpList.ThemeStyle.HeaderStyle.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 238);
            ExpList.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            ExpList.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            ExpList.ThemeStyle.HeaderStyle.Height = 4;
            ExpList.ThemeStyle.ReadOnly = false;
            ExpList.ThemeStyle.RowsStyle.BackColor = Color.White;
            ExpList.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            ExpList.ThemeStyle.RowsStyle.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 238);
            ExpList.ThemeStyle.RowsStyle.ForeColor = Color.FromArgb(71, 69, 94);
            ExpList.ThemeStyle.RowsStyle.Height = 29;
            ExpList.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            ExpList.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            ExpList.CellContentClick += ExpList_CellContentClick;
            // 
            // ListaWydatkow
            // 
            ListaWydatkow.AutoSize = true;
            ListaWydatkow.Font = new Font("Times New Roman", 13.8F, FontStyle.Regular, GraphicsUnit.Point, 238);
            ListaWydatkow.ForeColor = Color.FromArgb(240, 236, 229);
            ListaWydatkow.Location = new Point(746, 90);
            ListaWydatkow.Name = "ListaWydatkow";
            ListaWydatkow.Size = new Size(159, 26);
            ListaWydatkow.TabIndex = 16;
            ListaWydatkow.Text = "Lista wydatków";
            // 
            // DateTab
            // 
            DateTab.Checked = true;
            DateTab.CustomizableEdges = customizableEdges1;
            DateTab.FillColor = SystemColors.HighlightText;
            DateTab.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 238);
            DateTab.Format = DateTimePickerFormat.Short;
            DateTab.Location = new Point(108, 401);
            DateTab.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            DateTab.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            DateTab.Name = "DateTab";
            DateTab.ShadowDecoration.CustomizableEdges = customizableEdges2;
            DateTab.Size = new Size(250, 45);
            DateTab.TabIndex = 35;
            DateTab.Value = new DateTime(2023, 12, 17, 19, 50, 19, 566);
            // 
            // Expenses
            // 
            AutoScaleDimensions = new SizeF(11F, 22F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(22, 26, 48);
            ClientSize = new Size(1339, 728);
            Controls.Add(DateTab);
            Controls.Add(ListaWydatkow);
            Controls.Add(ExpList);
            Controls.Add(Usuń);
            Controls.Add(Edytuj);
            Controls.Add(Dodaj);
            Controls.Add(ExpValueBox);
            Controls.Add(ExpCatBox);
            Controls.Add(ExpDescBox);
            Controls.Add(Opis);
            Controls.Add(Data);
            Controls.Add(Kategoria);
            Controls.Add(Wartość);
            Controls.Add(Wydatek);
            Controls.Add(ExpNameBox);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 238);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4, 3, 4, 3);
            Name = "Expenses";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            panel1.ResumeLayout(false);
            panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)ExpList).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private PictureBox pictureBox5;
        private TextBox ExpNameBox;
        private Label Wydatek;
        private Label Wartość;
        private Label Kategoria;
        private Label Data;
        private Label Opis;
        private TextBox ExpDescBox;
        private TextBox ExpCatBox;
        private TextBox ExpValueBox;
        private Button Dodaj;
        private Button Edytuj;
        private Button Usuń;
        private Guna.UI2.WinForms.Guna2DataGridView ExpList;
        private Label ZarzadzanieFinansami;
        private PictureBox pictureBox6;
        private Label ListaWydatkow;
        private Panel panel3;
        private PictureBox pictureBox7;
        private PictureBox pictureBox8;
        private PictureBox pictureBox10;
        private PictureBox pictureBox11;
        private Guna.UI2.WinForms.Guna2DateTimePicker DateTab;
    }
}
